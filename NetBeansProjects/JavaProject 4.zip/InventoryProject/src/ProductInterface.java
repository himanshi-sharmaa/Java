import java.util.ArrayList;


public interface ProductInterface {
	
	void ShowProducts(ArrayList<Product> mp);
	ArrayList<Product> GetProducts(int n);

}
