import java.util.ArrayList;


public interface EmployeePortal {
	
	ArrayList<Employee> GetEmployeeDetails(int n);
	void ShowAllEmployees(ArrayList<Employee> emps);

}
