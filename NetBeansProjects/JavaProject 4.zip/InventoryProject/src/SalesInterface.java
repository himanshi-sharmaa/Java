
public interface SalesInterface {
	void SalesAmmount();

}
