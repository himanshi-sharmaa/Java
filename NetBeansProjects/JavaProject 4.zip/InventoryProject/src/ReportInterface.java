
public interface ReportInterface {
	
	void ShowReport();

}
